extends Node3D
# FEATHER FURY - original 3D chicken shooter prototype

const CITY_SCALE := 0.01
const ENEMY_NAMES := ["Rooster Raider", "Cluck Bandit", "Egg Bomber", "Feather Ninja", "Peck Sergeant"]

var player: CharacterBody3D
var cam: Camera3D
var weapon_holder: Node3D
var weapons: Array[Node3D] = []
var weapon_idx := 0
var spawn_points: Array[Vector3] = []
var hp := 100.0
var score := 0
var wave := 0
var alive_bots := 0
var started := false
var fire_cd := 0.0
var yaw := 0.0
var pitch := 0.0
var vel_y := 0.0

# touch state
var move_touch := -1
var look_touch := -1
var move_origin := Vector2.ZERO
var move_vec := Vector2.ZERO
var fire_down := false

var ui: CanvasLayer
var hud_label: Label
var msg_label: Label
var title_box: Control
var stick_base: Control
var stick_knob: Control

func _ready() -> void:
	randomize()
	_build_world()
	_build_ui()
	await get_tree().physics_frame
	await get_tree().physics_frame
	_find_spawn_points()
	_build_player()
	_show_title("FEATHER FURY", "TAP TO START")

# ---------- world ----------
func _build_world() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	e.sky = sky
	e.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.environment = e
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 35, 0)
	add_child(sun)
	var city: Node3D = (load("res://assets/models/city.glb") as PackedScene).instantiate()
	city.scale = Vector3.ONE * CITY_SCALE
	add_child(city)
	_add_collision(city)
	# fallback ground so nobody falls forever
	var ground := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	cs.shape = WorldBoundaryShape3D.new()
	ground.add_child(cs)
	ground.position.y = -8.0
	add_child(ground)

func _add_collision(n: Node) -> void:
	if n is MeshInstance3D:
		(n as MeshInstance3D).create_trimesh_collision()
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color.from_hsv(randf_range(0.05, 0.12), 0.15, randf_range(0.55, 0.85))
		(n as MeshInstance3D).material_override = mat
	for c in n.get_children():
		_add_collision(c)

func _find_spawn_points() -> void:
	var space := get_world_3d().direct_space_state
	var tries := 0
	while spawn_points.size() < 40 and tries < 600:
		tries += 1
		var x := randf_range(-300.0, 300.0)
		var z := randf_range(-250.0, 250.0)
		var q := PhysicsRayQueryParameters3D.create(Vector3(x, 120, z), Vector3(x, -20, z))
		var r := space.intersect_ray(q)
		if r and r.position.y < 4.0 and r.position.y > -6.0 and r.normal.y > 0.9:
			spawn_points.append(r.position + Vector3(0, 1.0, 0))
	if spawn_points.is_empty():
		spawn_points.append(Vector3(0, 5, 0))

# ---------- models ----------
func _fit_height(n: Node3D, h: float) -> void:
	var box := _aabb(n)
	if box.size.y > 0.0001:
		n.scale *= h / box.size.y

func _aabb(n: Node) -> AABB:
	var box := AABB()
	var first := true
	for m in n.find_children("*", "MeshInstance3D", true, false):
		var mi := m as MeshInstance3D
		var b := mi.global_transform * mi.get_aabb()
		if first:
			box = b
			first = false
		else:
			box = box.merge(b)
	return box

func _tint(n: Node, color: Color) -> void:
	for m in n.find_children("*", "MeshInstance3D", true, false):
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.roughness = 0.8
		(m as MeshInstance3D).material_override = mat

func _make_hen(color: Color) -> Node3D:
	var hen: Node3D = (load("res://assets/models/hen.fbx") as PackedScene).instantiate()
	var holder := Node3D.new()
	holder.add_child(hen)
	add_child(holder)
	_fit_height(holder, 1.2)
	remove_child(holder)
	_tint(hen, color)
	return holder

# ---------- player ----------
func _build_player() -> void:
	player = CharacterBody3D.new()
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.5
	cs.shape = cap
	player.add_child(cs)
	player.collision_layer = 4
	player.collision_mask = 1 | 2
	cam = Camera3D.new()
	cam.position = Vector3(0, 0.55, 0)
	cam.fov = 75
	cam.far = 800
	player.add_child(cam)
	add_child(player)
	weapon_holder = Node3D.new()
	weapon_holder.position = Vector3(0.28, -0.25, -0.5)
	cam.add_child(weapon_holder)
	_build_weapons()
	player.position = spawn_points[0]

func _build_weapons() -> void:
	var glock: Node3D = (load("res://assets/models/glock17.fbx") as PackedScene).instantiate()
	var g_holder := Node3D.new()
	g_holder.add_child(glock)
	weapon_holder.add_child(g_holder)
	var gt := StandardMaterial3D.new()
	gt.albedo_texture = load("res://assets/tex/glock_BaseColor.png")
	gt.metallic = 0.4
	gt.roughness = 0.5
	for m in glock.find_children("*", "MeshInstance3D", true, false):
		(m as MeshInstance3D).material_override = gt
	_fit_length(g_holder, 0.4)
	weapons.append(g_holder)
	var m4: Node3D = (load("res://assets/models/m4.glb") as PackedScene).instantiate()
	var m_holder := Node3D.new()
	m_holder.add_child(m4)
	m_holder.rotation_degrees.y = -90
	weapon_holder.add_child(m_holder)
	_tint(m4, Color(0.15, 0.15, 0.17))
	_fit_length(m_holder, 0.9)
	weapons.append(m_holder)
	_set_weapon(0)

func _fit_length(n: Node3D, length: float) -> void:
	var box := _aabb(n)
	var longest := maxf(box.size.x, maxf(box.size.y, box.size.z))
	if longest > 0.0001:
		n.scale *= length / longest

func _set_weapon(i: int) -> void:
	weapon_idx = i
	for k in weapons.size():
		weapons[k].visible = (k == i)

func _toggle_weapon() -> void:
	_set_weapon((weapon_idx + 1) % weapons.size())

# ---------- waves / bots ----------
func _start_wave() -> void:
	wave += 1
	var n := 2 + wave * 2
	_msg("WAVE %d" % wave, 1.5)
	for i in n:
		_spawn_bot()

func _spawn_bot() -> void:
	var bot := CharacterBody3D.new()
	bot.add_to_group("bot")
	bot.collision_layer = 2
	bot.collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.2
	cs.shape = cap
	bot.add_child(cs)
	var skin := _make_hen(Color.from_hsv(randf(), 0.6, 0.9))
	skin.position.y = -0.6
	bot.add_child(skin)
	bot.set_script(load("res://scripts/bot.gd"))
	bot.set("hp", 40.0 + wave * 8.0)
	bot.set("bot_name", ENEMY_NAMES[randi() % ENEMY_NAMES.size()])
	bot.set("target", player)
	bot.set("main", self)
	add_child(bot)
	var p := spawn_points[randi() % spawn_points.size()]
	bot.global_position = p
	alive_bots += 1

func bot_died() -> void:
	alive_bots -= 1
	score += 10
	if alive_bots <= 0 and started:
		await get_tree().create_timer(2.0).timeout
		if started:
			_start_wave()

func hurt_player(d: float) -> void:
	if not started:
		return
	hp -= d
	if hp <= 0.0:
		_game_over()

func _game_over() -> void:
	started = false
	for b in get_tree().get_nodes_in_group("bot"):
		b.queue_free()
	_show_title("GAME OVER", "Score: %d   -   tap to play again" % score)

func _begin() -> void:
	hp = 100.0
	score = 0
	wave = 0
	alive_bots = 0
	started = true
	player.position = spawn_points[randi() % spawn_points.size()]
	title_box.visible = false
	_start_wave()

# ---------- shooting ----------
func _shoot() -> void:
	var dmg := 20.0 if weapon_idx == 0 else 12.0
	fire_cd = 0.35 if weapon_idx == 0 else 0.1
	var from := cam.global_position
	var dir := -cam.global_transform.basis.z
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 200.0, 1 | 2)
	q.exclude = [player.get_rid()]
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	var tween := create_tween()
	tween.tween_property(weapon_holder, "position:z", -0.42, 0.04)
	tween.tween_property(weapon_holder, "position:z", -0.5, 0.08)
	if r and r.collider.has_method("take_damage"):
		r.collider.take_damage(dmg)

# ---------- ui ----------
func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	hud_label = Label.new()
	hud_label.position = Vector2(24, 16)
	hud_label.add_theme_font_size_override("font_size", 30)
	ui.add_child(hud_label)
	msg_label = Label.new()
	msg_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	msg_label.position.y = 80
	msg_label.add_theme_font_size_override("font_size", 56)
	ui.add_child(msg_label)
	var cross := Label.new()
	cross.text = "+"
	cross.add_theme_font_size_override("font_size", 40)
	cross.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	ui.add_child(cross)
	title_box = ColorRect.new()
	(title_box as ColorRect).color = Color(0, 0, 0, 0.6)
	title_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(title_box)
	stick_base = ColorRect.new()
	(stick_base as ColorRect).color = Color(1, 1, 1, 0.15)
	stick_base.size = Vector2(180, 180)
	stick_base.visible = false
	ui.add_child(stick_base)
	stick_knob = ColorRect.new()
	(stick_knob as ColorRect).color = Color(1, 1, 1, 0.45)
	stick_knob.size = Vector2(70, 70)
	stick_knob.visible = false
	ui.add_child(stick_knob)
	_make_button("FIRE", Vector2(1, 1), Vector2(-230, -230), Vector2(170, 170), func(down): fire_down = down)
	_make_button("JUMP", Vector2(1, 1), Vector2(-420, -150), Vector2(120, 120), func(down): if down and player.is_on_floor(): vel_y = 7.0)
	_make_button("GUN", Vector2(1, 0), Vector2(-150, 20), Vector2(120, 80), func(down): if down: _toggle_weapon())

func _make_button(text: String, anchor: Vector2, offset: Vector2, size: Vector2, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.anchor_left = anchor.x
	b.anchor_right = anchor.x
	b.anchor_top = anchor.y
	b.anchor_bottom = anchor.y
	b.offset_left = offset.x
	b.offset_top = offset.y
	b.offset_right = offset.x + size.x
	b.offset_bottom = offset.y + size.y
	b.add_theme_font_size_override("font_size", 28)
	b.button_down.connect(func(): cb.call(true))
	b.button_up.connect(func(): cb.call(false))
	ui.add_child(b)

func _show_title(t: String, sub: String) -> void:
	for c in title_box.get_children():
		c.queue_free()
	var l := Label.new()
	l.text = t + "\n" + sub
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 64)
	l.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	l.grow_horizontal = Control.GROW_DIRECTION_BOTH
	l.grow_vertical = Control.GROW_DIRECTION_BOTH
	title_box.add_child(l)
	title_box.visible = true

func _msg(t: String, secs: float) -> void:
	msg_label.text = t
	await get_tree().create_timer(secs).timeout
	msg_label.text = ""

# ---------- input ----------
func _input(event: InputEvent) -> void:
	if not started:
		if event is InputEventScreenTouch and event.pressed and player != null:
			_begin()
		return
	var half := get_viewport().get_visible_rect().size.x * 0.5
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < half and move_touch == -1:
				move_touch = event.index
				move_origin = event.position
				stick_base.position = event.position - stick_base.size * 0.5
				stick_knob.position = event.position - stick_knob.size * 0.5
				stick_base.visible = true
				stick_knob.visible = true
			elif event.position.x >= half and look_touch == -1 and event.position.x < get_viewport().get_visible_rect().size.x - 450:
				look_touch = event.index
		else:
			if event.index == move_touch:
				move_touch = -1
				move_vec = Vector2.ZERO
				stick_base.visible = false
				stick_knob.visible = false
			if event.index == look_touch:
				look_touch = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch:
			var d: Vector2 = (event.position - move_origin).limit_length(90.0)
			move_vec = d / 90.0
			stick_knob.position = move_origin + d - stick_knob.size * 0.5
		elif event.index == look_touch:
			yaw -= event.relative.x * 0.005
			pitch = clampf(pitch - event.relative.y * 0.005, -1.4, 1.4)

func _physics_process(delta: float) -> void:
	if player == null:
		return
	hud_label.text = "HP %d   SCORE %d   WAVE %d" % [maxf(hp, 0.0), score, wave]
	if not started:
		return
	var kb := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	var mv := move_vec if move_vec != Vector2.ZERO else kb
	player.rotation.y = yaw
	cam.rotation.x = pitch
	var dir := (player.global_transform.basis * Vector3(mv.x, 0, mv.y)).normalized() * mv.length()
	player.velocity.x = dir.x * 7.0
	player.velocity.z = dir.z * 7.0
	vel_y -= 20.0 * delta
	if player.is_on_floor() and vel_y < 0.0:
		vel_y = 0.0
	player.velocity.y = vel_y
	player.move_and_slide()
	fire_cd -= delta
	if fire_down and fire_cd <= 0.0:
		_shoot()
