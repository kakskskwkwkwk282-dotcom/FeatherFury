extends CharacterBody3D
# Enemy hen bot: chases the player and pecks/shoots when close

var hp := 50.0
var bot_name := "Cluck Bandit"
var target: Node3D
var main: Node
var attack_cd := 1.0
var dead := false
var label: Label3D

func _ready() -> void:
	label = Label3D.new()
	label.text = bot_name
	label.position.y = 1.0
	label.pixel_size = 0.004
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	add_child(label)

func take_damage(d: float) -> void:
	if dead:
		return
	hp -= d
	if hp <= 0.0:
		dead = true
		main.bot_died()
		queue_free()

func _physics_process(delta: float) -> void:
	if dead or target == null:
		return
	var to := target.global_position - global_position
	var flat := Vector3(to.x, 0, to.z)
	var dist := flat.length()
	if dist > 1.0:
		look_at(global_position + flat, Vector3.UP)
	if dist > 6.0 and dist < 80.0:
		var d := flat.normalized() * 4.0
		velocity.x = d.x
		velocity.z = d.z
	else:
		velocity.x = 0.0
		velocity.z = 0.0
	velocity.y -= 20.0 * delta
	move_and_slide()
	attack_cd -= delta
	if dist < 30.0 and attack_cd <= 0.0:
		attack_cd = randf_range(0.9, 1.6)
		if randf() < 0.5:
			main.hurt_player(6.0)
