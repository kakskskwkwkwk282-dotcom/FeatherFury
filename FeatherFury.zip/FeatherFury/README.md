# Feather Fury

Original 3D chicken shooter (Godot 4.3).

## Build the APK without installing anything
1. Create a new repository on GitHub and upload all files of this folder.
2. Open the repository -> Actions -> "Build APK" -> Run workflow.
3. When it finishes, download `FeatherFury-apk` from the run page and install the APK.

Change `package/unique_name` in `export_presets.cfg` to your own id before publishing.
